import sys
from pyspark import SparkContext

# Check for correct number of arguments
if len(sys.argv) != 4:
    print("Usage: script.py <input_file> <min_output_dir> <max_output_dir>")
    sys.exit(1)

# Initialize Spark context
sc = SparkContext()

try:
    # Read the input file
    f = sc.textFile(sys.argv[1])

    # Map to (key, value) pairs
    temp = f.map(lambda x: (int(x[15:19]), int(x[87:92])))

    # Calculate minimum values
    mini = temp.reduceByKey(lambda a, b: a if a < b else b)
    mini.saveAsTextFile(sys.argv[2])

    # Calculate maximum values
    maxi = temp.reduceByKey(lambda a, b: a if a > b else b)
    maxi.saveAsTextFile(sys.argv[3])

except Exception as e:
    print(f"An error occurred: {e}")
finally:
    # Stop the Spark context
    sc.stop()
