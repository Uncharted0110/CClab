export PATH=$(echo $PATH):$(pwd)/bin
